#if defined(QTFIREBASE_AUTO_REGISTER)
#include "qtfirebase_register.h"
#endif
