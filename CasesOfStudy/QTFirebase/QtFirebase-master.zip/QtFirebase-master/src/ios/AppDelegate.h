#import <UIKit/UIKit.h>

#import "Firebase/Firebase.h"

@interface AppDelegate : UIResponder<UIApplicationDelegate>

+(AppDelegate *)sharedAppDelegate;

@end
