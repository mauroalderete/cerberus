#!/bin/bash

curl --location https://firebase.google.com/download/ios --output "firebase_ios.zip"
unzip firebase_ios.zip
rm firebase_ios.zip
